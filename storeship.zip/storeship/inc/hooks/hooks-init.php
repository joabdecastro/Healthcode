<?php
    /**
     * Header section.
     */
    
    require get_template_directory() . '/inc/hooks/hook-header-section.php';
